# Hero (Liquid)
> Última actualización: 19 de Marzo, 2026

> **TL;DR:** Hero principal con efecto líquido, animación de chat secuencial, y CTA a Calendly. GSAP orchestrado con stagger reveals.

## Componentes
- `src/components/landing-v2/hero/LiquidHero.tsx` — Hero principal
- `src/components/landing-v2/hero/HeroChatAnimation.tsx` — Animación de chat bubbles

## Estado Actual
- Funcional con animación de entrada secuencial y efecto líquido.

## Historial de Cambios
- *Se poblará conforme se trabaje en esta sección.*

## Decisiones de Diseño
- *Pendiente de documentar.*

## Bugs Conocidos / Pendientes
- Ninguno conocido.
