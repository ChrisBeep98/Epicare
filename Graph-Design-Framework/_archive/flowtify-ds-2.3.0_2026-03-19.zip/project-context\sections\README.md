# 📂 Contexto por Sección — Inventario

> **Propósito:** Cada sección del proyecto tiene su propia carpeta de contexto. Cuando un agente va a trabajar en una sección específica, lee SOLO el archivo de esa sección para cargar su historial, decisiones de diseño, y estado actual.

## 🗺️ Mapa de Secciones (Orden de Render en `page.tsx`)

| # | Sección | Carpeta | Componente(s) | Estado |
|:--|:---|:---|:---|:---|
| 0 | **Header** | [`header/`](./header/) | `Header.tsx`, `IsotipoFlowtify.tsx`, `LanguageToggle.tsx` | ✅ Activo |
| 1 | **Hero (Liquid)** | [`hero/`](./hero/) | `LiquidHero.tsx`, `HeroChatAnimation.tsx` | ✅ Activo |
| 2 | **Hero Image** | [`hero-image/`](./hero-image/) | `HeroImage.tsx` | ✅ Activo |
| 3 | **Services Bento** | [`services-bento/`](./services-bento/) | `ServicesBento.tsx`, `HoverArrowBubble.tsx` | ✅ Activo |
| 4 | **Wave Reveal** | [`wave-reveal/`](./wave-reveal/) | `WaveRevealSection.tsx` | ✅ Activo |
| 5 | **Integrations** | [`integrations/`](./integrations/) | `IntegrationsEcosystem.tsx` | ✅ Activo |
| 6 | **Comparison** | [`comparison/`](./comparison/) | `ComparisonSection.tsx` | ✅ Activo |
| 7 | **Testimonials** | [`testimonials/`](./testimonials/) | `TestimonialsCarousel.tsx` | ✅ Activo |
| 8 | **Dashboard Reveal** | [`dashboard-reveal/`](./dashboard-reveal/) | `DashboardReveal.tsx` | ✅ Activo |
| 9 | **Calculator** | [`calculator/`](./calculator/) | `HomeCalculator.tsx`, `CalcCard.tsx`, `CalcSlider.tsx`, `AnimNum.tsx`, `BigStat.tsx` | ✅ Activo |
| 10 | **Footer** | [`footer/`](./footer/) | `Footer.tsx` | ✅ Activo |
| — | **FlowSell Hero** | [`flowsell-hero/`](./flowsell-hero/) | `FlowSellHero.tsx` | 🚧 En desarrollo |

## 📄 Formato de Archivo por Sección

Cada carpeta debe contener un archivo `context.md` con este formato:

```markdown
# [Nombre de la Sección]
> Última actualización: [fecha]

## Componentes
- Lista de archivos .tsx/.ts involucrados

## Estado Actual
- Descripción breve del estado visual y funcional

## Historial de Cambios
- Entradas cronológicas de qué se hizo, en el mismo formato que el context.md global

## Decisiones de Diseño
- Por qué se eligió X sobre Y (ej: "Se descartó IntersectionObserver por race conditions")

## Bugs Conocidos / Pendientes
- Lista de issues conocidos o mejoras pendientes
```

## 🔄 Protocolo de Uso

1. **Al trabajar en una sección:** El agente lee `sections/[nombre]/context.md` ANTES de empezar.
2. **Al terminar un hito:** El agente actualiza el `context.md` de esa sección con la nueva entrada.
3. **Nueva sección:** Crear la carpeta + `context.md` con el formato estándar.
