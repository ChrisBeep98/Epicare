# Header — Adaptive Pill System

## Resumen
El header de Flowtify cambia dinámicamente su apariencia (colores de logo, texto, botones) según la sección visible detrás de él. Usa `IntersectionObserver` para detectar qué sección está en la franja superior del viewport.

---

## Arquitectura

### Data Attributes en Secciones
Cada sección del landing tiene un atributo `data-header-pill` en su elemento raíz que declara qué modo de pill usar:

| Sección | Archivo | Valor |
|:--|:--|:--|
| LiquidHero | `hero/LiquidHero.tsx` | `light` |
| ScrollSequence | `ScrollSequence.tsx` | `dark` |
| FlowExplanation | `FlowExplanation.tsx` | `dark` |
| ServicesBento | `ServicesBento.tsx` | `light` |
| WaveRevealSection | `WaveRevealSection.tsx` | `light` |
| ComparisonSection | `ComparisonSection.tsx` | `light` |

### IntersectionObserver (Header.tsx)
- **rootMargin:** `'0px 0px -95% 0px'` → Solo observa los 5% superiores del viewport (donde vive el header)
- **threshold:** `0` → Se activa apenas el borde de la sección toca la zona
- **Cleanup:** `observer.disconnect()` en el return del `useEffect`
- **Performance:** Cero scroll listeners. El Observer corre fuera del main thread

### Modos del Pill

| Elemento | `light` (fondo oscuro) | `dark` (fondo claro) |
|:--|:--|:--|
| Logo Isotipo | Degradado original (brand) | Negro plano `#1D1D1F` |
| Texto "Flowtify" | Blanco | Negro `#1D1D1F` |
| Botón Login | `bg-white text-off-black` | `bg-[#1D1D1F] text-white` |
| Menú hamburguesa | Blanco | Negro `#1D1D1F` |

Todas las transiciones son `duration-300`.

---

## Cómo agregar una nueva sección

1. Añade `data-header-pill="light"` o `"dark"` al elemento raíz de tu nueva sección
2. No necesitas tocar `Header.tsx` — el Observer detecta automáticamente todos los `[data-header-pill]`

---

## Componente del Logo (IsotipoFlowtify)
El componente acepta un prop `color?: string`:
- **Sin color:** Muestra el degradado SVG original (Violet → Blue → Cyan)
- **Con color:** Las 3 paths del SVG usan ese color sólido plano
- **Transición:** `fill` tiene `transition: 0.5s ease` en cada `<path>`

---

## Archivos Involucrados
- `src/components/landing-v2/header/Header.tsx` — IntersectionObserver + estilos condicionales
- `src/components/landing-v2/icons/IsotipoFlowtify.tsx` — Prop `color` para flat color
- Cada sección del landing → atributo `data-header-pill`
