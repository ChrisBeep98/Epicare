# FLOWTIFY AI // DESIGN SYSTEM & TOKENS

Este archivo es la **Única Fuente de Verdad (Single Source of Truth)**. Define la jerarquía visual que debe estar sincronizada con `app-v1/app/globals.css`.

---

## 🛠️ IMPLEMENTACIÓN TÉCNICA
- **Ubicación de Variables:** `app-v1/app/globals.css`
- **Metodología:** Tailwind v4 (@theme inline + @utility)

---

## 🖼️ 1. MARCOS Y MÁRGENES (The Page Frame)

> **⚠️ NOTA (Marzo 2026):** El token `.px-frame` fue deprecado. Los contenedores principales ahora usan padding fluido nativo.

| Dispositivo | Valor Real | Implementación Actual |
| :--- | :--- | :--- |
| **Móvil** | **14px** | `px-[14px]` |
| **Tablet+** | **clamp(1.5rem, 4vw, 3.5rem)** | `md:px-[clamp(1.5rem,4vw,3.5rem)]` |
| **Max Width** | **1400px** | `max-w-[1400px] mx-auto` |

---

## 📏 1.2 ESPACIADO VERTICAL (Section Padding)
Define el **ritmo vertical** entre bloques de contenido.

| Escenario | Espacio Total Deseado | Clase CSS |
| :--- | :--- | :--- |
| **Móvil** | **80px** | `.section-v-spacing` |
| **Desktop** | **160px** | `.section-v-spacing` |

---

## 📐 2. TYPOGRAPHY TOKENS (Semánticos & Cognitivos)

> **Regla de Oro (Cognitive Typographer):** Nunca usar anchos infinitos. Los títulos usan `text-balance`, los párrafos usan `text-pretty` y máximo `max-w-prose` (o equivalente).
> **Fuentes Premium:** Usar **Outfit** estrictamente para titulares/Display, y **Satoshi** (Fontshare) para texto de lectura y cuerpo.

| # | Token | Clase CSS | Fuente | Tamaño (Fluid) | Peso | Line-Height | Tracking | Wrap |
| :-- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| 1 | **DISPLAY** | `.text-display` | Outfit | `clamp(3rem, 5vw, 6rem)` | `800` | `1.05` | `-0.04em` | `balance` |
| 1.5 | **DISPLAY-SM** | `.text-display-sm` | Outfit | `clamp(3rem, 3.5vw, 3.625rem)` | `700` | `1.05` | `-0.04em` | `balance` |
| 2 | **H-SECTION** | `.text-h-section` | Outfit | `clamp(2rem, 4.5vw, 3.5rem)` | `700` | `1.1` | `-0.025em` | `balance` |
| 3 | **H-CARD** | `.text-h-card` | Outfit | `clamp(1.5rem, 3vw, 2.25rem)` | `600` | `1.2` | `-0.015em` | `balance` |
| 4 | **H-SUBTITLE** | `.text-h-subtitle` | Outfit | `clamp(1.25rem, 2.5vw, 1.75rem)` | `600` | `1.3` | `-0.01em` | `balance` |
| 5 | **H-SMALL** | `.text-h-small` | Outfit | `clamp(1.125rem, 2vw, 1.375rem)` | `600` | `1.3` | `0` | `balance` |
| 6 | **OVERLINE** | `.text-overline` | Satoshi | `clamp(0.6875rem, 1.1vw, 0.875rem)` | `600` | `1.4` | `0.1em` | UPPERCASE |
| 7 | **SUBTITLE** | `.text-subtitle` | Satoshi | `clamp(1.125rem, 1.8vw, 1.375rem)` | `500` | `1.4` | `-0.01em` | `pretty` |
| 7.5| **BODY-LG** | `.text-body-lg` | Satoshi | `1.125rem` (fijo) | `400` | `1.6` | `0` | `pretty` |
| 8 | **BODY-MD** | `.text-body-md`| Satoshi | `1.0625rem` (fijo)| `400` | `1.55`| `0` | `pretty` |
| 8.5| **BODY** | `.text-body` | Satoshi | `1rem` (fijo) | `400` | `1.6` | `0` | `pretty` |
| 9 | **BODY-SM** | `.text-body-sm` | Satoshi | `0.875rem` (fijo) | `400` | `1.5` | `0.01em` | `pretty` |
| 10 | **UI-LABEL** | `.text-ui-label` | Satoshi | `0.8125rem` (fijo) | `500` | `1.4` | `0.05em` | UPPERCASE |
| 11 | **NUM-DATA** | `.text-data` | Geist Mono | *(hereda del contexto)* | `700` | `1.2` | `-0.02em` | — |
| 12 | **CAPTION** | `.text-caption` | Satoshi | `0.75rem` (fijo) | `400` | `1.4` | `0.02em` | — |

### 2.1 Reglas de Escalado
- **Headings (1–7):** Todos usan `clamp()` para escalado fluido. El token maneja el tamaño automáticamente — NO es necesario agregar clases Tailwind de tamaño (`text-3xl`, `text-5xl`, etc.) junto al token.
- **Body (8–9):** Tamaño fijo en `rem`. No escalan con el viewport (correcto para legibilidad).
- **Labels/UI (10, 12):** Tamaño fijo en `rem`. Nunca en `px`.
- **Data (11):** Monoespaciada, tracking compacto para alinear dígitos.

### 2.2 🚨 Regla Crítica: NUNCA usar `px` para font-size

> **PROHIBIDO:** `text-[13px]`, `text-[16px]`, `font-size: 20px`
> **OBLIGATORIO:** `text-[0.8125rem]`, `text-base`, `font-size: 1.25rem`

- Cualquier valor de `text-[Xpx]` en un componente es una **violación** del Design System.
- `px` no escala con las preferencias de accesibilidad del usuario (zoom del navegador).
- `rem` escala proporcionalmente al `font-size` del `<html>`, respetando accesibilidad.
- **Excepciones:** Tipografía decorativa >100px (mega words de fondo).

---

## 🎨 3. COLOR PALETTE & MODES

### 3.0 FILOSOFÍA ATMOSFÉRICA (The Mood Direction)
- **⚡ VIBRANT ENERGY (Light Mode):** Direccionalidad hacia la claridad y el futuro. Evoca confianza, tecnología invisible y optimismo.
- **🚫 DARK MODE:** Desactivado completamente. La marca vive en la luz.
- **GLASSMORPHISM:** El material principal es el cristal blanco translúcido sobre fondos sutiles.

### 3.1 NÚCLEO ATMOSFÉRICO (Semantic Mapping)

| Variable CSS | Token Tailwind | Value (Light Mode Only) ☀️ | Uso |
| :--- | :--- | :--- | :--- |
| `--background` | `bg-background` | `#FFFFFF` (Pure White) | Lienzo principal |
| `--secondary-bg`| `bg-secondary` | `#F2F2F7` (Ghost) | Fondos alternativos / Secciones |
| `--foreground` | `text-foreground` | `#1D1D1F` (Off Black) | Texto principal |
| `--muted` | `text-muted` | `#6B7280` (Gray 500) | Textos secundarios |
| `--border` | `border-border` | `#E2E8F0` (Alice Blue/Gris) | Líneas divisorias |
| `--glass` | `bg-glass` | `rgba(255,255,255,0.7)` | Fondos con backdrop-blur |

### 3.1.5 Colores de Sistema (Feedback)
- **Success:** `#00D9A3` (Vivid)
- **Warning:** `#FB923C` (Vivid)
- **Error:** `#FF2D55` (Vivid)

### 3.2 BRAND ACCENTS (The 4-Pillar Gradient)
El gradiente principal representa el flujo de la tecnología.
- **Violet:** `#A40EBB` (Inicio)
- **Purple:** `#6607DE` (FlowDesk)
- **Electric Blue:** `#007AFF` (Transición)
- **Cyan:** `#5AC8FA` (FlowSell / Final)

> **Nota de Diseño Light Mode:** En modo claro, los acentos cian/naranja deben usarse con moderación para no competir con el fondo blanco. Preferir bordes o textos pequeños sobre fondos sólidos grandes.

---

## 🔘 4. INTERACTIVE COMPONENTS (Sync con Manual de Marca)

### **BTN-GRADIENT** (`.btn-hero-cta`)
El llamado a la acción principal del Hero (Atención máxima).
- **Fondo:** Gradiente Violeta a Morado (`#A40EBB` → `#6607DE`).
- **Texto:** `White` (#FFFFFF)
- **Forma:** `Rounded-xl` (12px) - Moderno y amigable.
- **Sombra:** `Shadow-lg` + Sombra suave del mismo gradiente.

### **BTN-PRIMARY** (`.btn-primary`)
Botones de acción estándar.
- **Fondo:** Azul Azure Sólido (`#007AFF`).
- **Texto:** `White` (#FFFFFF).

### **BTN-SECONDARY** (`.btn-secondary`)
Botones de apoyo o navegación (Ej. CTA Final Bloque 8).
- **Fondo:** `White` (#FFFFFF)
- **Texto:** Morado (`#6607DE`) o `text-foreground` (`#1D1D1F`).
- **Borde:** `border-border` (`#E2E8F0`) si no tiene fondo con gradiente.
- **Hover:** `bg-secondary` (`#F2F2F7`).

---

## 🤖 5. AI PROMPT & SYNC RULE
> **"Si vas a crear un botón o elemento interactivo, verifica siempre la sección 4 de este documento."**

---

## 🌍 6. INTERNATIONALIZATION (i18n)

### 6.1 ESTRATEGIA DE CONTENIDO
El diseño debe ser flexible para soportar la expansión de texto del Español vs Inglés (+25-30% de longitud promedio).

- **Layouts Flexibles:** Evitar anchos fijos (`width: 300px`) en contenedores de texto. Usar `min-width` o `max-width` con `flex-wrap`.
- **Botones:** Los botones deben crecer con el contenido. Evitar romper etiquetas de botones en dos líneas.

### 6.2 FORMATOS REGIONALES

| Dato | Español (ES) | Inglés (EN) | Token/Clase |
| :--- | :--- | :--- | :--- |
| **Ingresos** | `$1.200 USD` | `$1,200 USD` | `.text-data` |
| **Usuarios** | `1.5k Activos` | `1.5k Active` | `.text-ui-label` |
| **Fecha** | `03 ENE 2026` | `JAN 03, 2026` | `.text-muted` |

---

## 📝 7. CHANGELOG

| Fecha | Cambio |
|:---|:---|
| **2026-02-16** | Adaptación a Flowtify AI Identity. Light Mode Only. 4-Pillar Gradient. Botones y tipografía redefinidos. |
| **2026-02-22** | Sistema tipográfico de 12 tokens (Apple HIG + Major Third 1.25×). Integración de Satoshi vía Fontshare. Reemplazo de GT Walsheim Pro. |
| **2026-03-10** | Tokenización completa del Calculator. Todos los `text-[Xpx]` eliminados. Colores semánticos aplicados. |
| **2026-03-18** | Estandarización del grid a `max-w-[1400px]`. Token `.px-frame` deprecado → `clamp()` nativo. |
| **2026-03-19** | Tokens `DISPLAY-SM`, `BODY-LG`, `BODY-MD` añadidos a la escala tipográfica. Changelog creado. |

---

## 🎬 8. MOTION TOKENS (GSAP)
Estándares de animación para mantener la coherencia cinematográfica.

### 8.1 FLOW REVEAL (Títulos y Héroes)
El efecto estándar para revelar contenido con elegancia líquida.
- **Estilo:** "Liquid Fade Up".
- **Trigger:** `top 85%` del viewport.
- **Duration:** `1.4s`.
- **Ease:** `power4.out`.
- **Stagger:** `0.2s` (Entre líneas).
- **Start State:** `y: 40, opacity: 0`.
- **End State:** `y: 0, opacity: 1`.

### 8.2 COMPONENT FADE (Tarjetas y Elementos)
- **Duration:** `0.8s`.
- **Ease:** `power2.out`.
- **Distance:** `y: 30px`.