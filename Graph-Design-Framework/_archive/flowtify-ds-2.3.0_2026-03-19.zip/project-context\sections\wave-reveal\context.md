# Wave Reveal
> Última actualización: 19 de Marzo, 2026

> **TL;DR:** Galería de imágenes con reveal scroll-driven y wave mask SVG. Imágenes separadas desktop/mobile leídas con fs.readdir en build time.

## Componentes
- `src/components/landing-v2/WaveRevealSection.tsx` — Sección principal

## Estado Actual
- Funcional con ScrollTrigger pinning y wave mask transition entre imágenes.

## Historial de Cambios
- *Se poblará conforme se trabaje en esta sección.*

## Decisiones de Diseño
- *Pendiente de documentar.*

## Bugs Conocidos / Pendientes
- Ninguno conocido.
