# Contexto del Proyecto: Flowtify Landing Page Redesign
> **Última Actualización:** 19 de Marzo, 2026
> **Estado:** Fase 8 (Corporate Merge & Arquitectura Purificada FlowSell)
> **Navegación:** Ver [`README.md`](./README.md) para el índice completo de archivos de contexto.

## 1. Visión General
El objetivo de este esfuerzo es realizar un **rediseño completo de la página de inicio (Landing Page)** del proyecto `website-flowtify`. El proyecto original es una aplicación web robusta construida con Next.js (App Router), React 19, Supabase y Prisma, incluyendo paneles de administración protegidos.

El rediseño fue completado y **entregado** exitosamente. La rama `feature/redesign-landing` fue mergeada y el landing está en producción. El lead del equipo realizó ajustes post-entrega que fueron integrados vía `git pull origin main`.

## 2. Entorno y Stack Tecnológico
- **Framework Principal:** Next.js 16.1.4 (Turbopack)
- **Gestión de Estilos:** Tailwind CSS v4 (vía PostCSS) integrado orgánicamente. Globales centralizados en `landing.css`.
- **Librerías de UI:** `framer-motion` (v12.x), `gsap` (v3.14.x) y `lenis` (smooth scrolling).
- **Control de Versiones:** Git (Rama actual: `feature/redesign-landing`). Remotes: `origin` (flowtifyai/website-flowtify), `myfork` (ChrisBeep98/website-flowtify-fork).
- **Gestor de Paquetes:** `pnpm` (Estrictamente configurado).
- **Deploy:** Vercel (conectado al fork). Git user para commits: `ChrisBeep98` / `christiansandovaldesign@gmail.com`.

## 3. Estándares de Desarrollo (OBLIGATORIO)
Todo código entregado debe cumplir con los siguientes estándares de producción:

### Arquitectura
- **Modularidad:** Componentes grandes (>200 líneas) deben dividirse en sub-componentes, custom hooks, y archivos de tipos.
- **Separación de concerns:** Lógica de negocio en hooks (`use*.ts`), tipos en `types.ts`, UI en componentes `.tsx`.
- **Constantes:** Extraer a nivel de módulo con `UPPER_SNAKE_CASE`. No hardcodear valores mágicos inline.

### Código Limpio
- **JSDoc:** Todo componente exportado, hook, y función utilitaria debe tener JSDoc con `@description` y `@example` cuando sea relevante.
- **TypeScript estricto:** Interfaces explícitas para props. No usar `any`. Tipar retornos de hooks.
- **Comentarios de sección:** Bloques lógicos separados con comentarios descriptivos (`// ── SECTION ──`).

### Design System
- **Tipografía:** Usar EXCLUSIVAMENTE tokens del sistema tipográfico (`text-display`, `text-h-section`, `text-h-card`, `text-h-subtitle`, `text-h-small`, `text-overline`, `text-subtitle`, `text-body`, `text-body-sm`, `text-ui-label`, `text-data`, `text-caption`). **PROHIBIDO** usar `text-[Xpx]` o `text-[Xrem]` arbitrarios.
- **Colores:** Usar variables semánticas de Flowtify (`flowtify-text-primary`, `flowtify-text-muted`, `flowtify-red`, `flowtify-green`, `flowtify-blue`, `border-border`, `flowtify-bg-secondary`). Minimizar uso de colores genéricos de Tailwind (`slate-*`, `gray-*`).
- **Modo:** Light-mode only. No implementar dark mode.

### Tooling
- **Gestor de paquetes:** `pnpm` — NUNCA usar `npm` ni `yarn`.
- **Build:** Verificar con `pnpm build` antes de entregar. Cero errores TypeScript.
- **i18n:** Todo texto visible al usuario debe usar `useTranslations()` de `next-intl`. No hardcodear strings en JSX.
- **Rendimiento:** Usar `useMemo` para cálculos derivados costosos. Limpiar efectos (GSAP `.revert()`, `cancelAnimationFrame`, etc.).

## 4. Estructura de la Migración
Los componentes del nuevo diseño están consolidados en:
- **Componentes V2:** `src/components/landing-v2/` (Incluye `LiquidHero`, `ModulesCarousel`, `ComparisonSection`, `WaveRevealSection`, `IntegrationsEcosystem`, `DashboardReveal`, `Footer`).
- **Módulo Calculator:** `src/components/landing-v2/calculator/` — Arquitectura modular con 8 archivos: `HomeCalculator.tsx` (orquestador), `useCalculator.ts` (hook), `AnimNum.tsx`, `CalcSlider.tsx`, `CalcCard.tsx`, `BigStat.tsx`, `CalcWaves.tsx` (BG + debug panel), `types.ts`.
- **Testimonials Ticker:** `src/components/landing-v2/TestimonialsCarousel.tsx` — Ticker horizontal auto-scroll con avatares, quotes, trust messages con emojis. CSS marquee en `landing.css`.
- **Assets Públicos:** `/public/hero-sequence/*`, `/public/Dashboard-UI-Mockup/*`, `/public/Hero-Video_02-Mobile.mp4`, `/public/landing/calculator/TESTING-IMAGES-BG/` (13 imágenes de fondo para testeo), etc.
- **Ruta Principal:** `src/app/page.tsx` (Completamente refactorizada para consumir V2, incluye Footer cortina y Calculator).
- **Estilos Comunes:** Todas las variables `--color-pillar-*` y clases utilitarias (`.liquid-glass`, `.footer-animated-bg`, degradados, marquee) fueron modularizadas en `landing.css`.

## 5. Registro de Acciones Críticas Realizadas

> **📦 Entradas Archivadas (#1-#38):** Las fases 1-7 del proyecto (Feb–16 Mar 2026) fueron archivadas en [`context-archive-phase1-7.md`](./context-archive-phase1-7.md). Cubren: configuración inicial, migración Core V2, sistema tipográfico 12 tokens, Comparison Section, Calculator (implementación + refactor + mobile), Testimonials Ticker, Footer cortina, Bento cards polish, CI/CD & merge resolution, y la entrega del Landing.

### Fase 8 — Acciones Activas (18-19 Mar 2026)

39. **[NUEVO] FlowSell Hero — Implementación V2 & Cinematic Sync (18 Mar 2026):**
    - Creación funcional del esqueleto `src/components/flowsell/Hero.tsx` implementando textos localizados (`next-intl`) y la animación maestro-secuencial vía `gsap.timeline`.
    - **Solución al Salto de Fotogramas de Video:** Se modificó la invocación `.play()` del background video al evento `onStart` de su propia transición de opacidad (con `currentTime = 0`), sincronizando el milisegundo exacto de aparición para evitar fotogramas congelados en el *fade-in*.
40. **[NUEVO] Unificación Matemática del Grid Arquitectónico (18 Mar 2026):**
    - Se descubrió un defecto crítico de consistencia visual en monitores ultrawide (1920px+): `LiquidHero` usaba un contenedor de 1800px, mientras que `Header` y `FlowSellHero` orbitaban en lógicas sin definir o separadas.
    - **Estandarización al framework de 1400px:** Se inyectó estrictamente el límite `w-full max-w-[1400px]` en las tres entidades (Header, Flowsell, Landing) para garantizar paralelismo de columnas invisibles en toda la App.
    - **Padding Fluido Exterior (Resolución Quirúrgica):** Se reemplazó el token fantasma `.px-frame` por el cálculo nativo `md:px-[clamp(1.5rem,4vw,3.5rem)]`. Este token fue migrado forzosamente a la capa exterior de los 3 envoltorios globales (`<section>` y `<motion.header>`) eliminando rellenos duplicados y aplastamientos de layout.
    - El widget `LanguageToggle` de escritorio se migró de la sección Izquierda (al lado del logotipo IsotipoFlowtify) a la sección Derecha (junto al botón CTA de Log In).
    - Se optimizaron los contenedores flex desactivando clases obsoletas para establecer una simetría absoluta (`gap-[12px]`) entre los controles de acción y sus barras separadoras verticales.
42. **[NUEVO] FlowSell Hero — Refactor de Nomenclatura & Disambiguación (19 Mar 2026):**
    - El archivo `Hero.tsx` fue renombrado seguramente vía Git a `FlowSellHero.tsx` para evitar fricción semántica en producción.
    - Las clases CSS y hooks de GSAP fueron reclasificadas estrictamente (`flowsell-hero-eyebrow`, `flowsell-water-mask-text`, etc.) para garantizar aislamiento total contra el `LiquidHero` de la Landing.
    - **Tipografía Responsiva:** Se forzó una reducción de `~16px` en el H1 de móvil usando el utilitario `text-[24px]` sobreescribiendo temporalmente el token `text-display-sm` para evitar overflows.
43. **[NUEVO] Debug Panel Architect — Fase 3: Zero-Trace Purge (19 Mar 2026):**
    - Eliminación completa de +180 líneas de código temporal inyectadas correspondientes a los controles UI de testeo *en vivo*.
    - **Consolidación del Background:** Se dividieron los flujos visuales en dos nodos estáticos de `<video>`, aislando nativamente Desktop (`hidden md:block`) de Mobile (`md:hidden`).
    - Configuración en piedra de máscaras lineales CSS (e.g. 34% top fade en mobile, 9% en desktop). Soporte doble referencia `useRef` para orquestación GSAP simultánea.
    - **Optimizador Git:** Se purgaron del file system 12 archivos `.mp4` inutilizados de pruebas heurísticas para aligerar radicalmente el build de Vercel.
44. **[NUEVO] Integración Upstream Automática (19 Mar 2026):**
    - Se ejecutó el pipeline de CI/CD local (`git fetch` + `git merge origin/main`) tras asegurar toda la UI con su propio commit local de backup.
    - El merge resolvió mágicamente con estrategia `ort` con **0 conflictos**, blindando 100% de nuestras optimizaciones Landing contra los nuevos módulos robustos de Auntenticación del lead developer.


## 6. Próximos Pasos (To-Do)
- Verificar visualmente el ticker de testimonials y la calculadora en mobile y desktop.
- Investigar y resolver el gap blanco de ~80px en el fondo de la sección calculator (puede ser causado por la viñeta radial o elementos padres).
- Considerar reemplazar avatares de `ui-avatars.com` con fotos reales cuando estén disponibles.
- Recibir y ejecutar nuevas tareas asignadas por el lead.
