---
name: Agent Skills Index
description: Navigation index and recommended reading order for all Flowtify Design Agent Skills.
---

# 🧠 Flowtify Design Agent Skills — Índice

> **Propósito:** Este directorio contiene los protocolos de comportamiento modulares para agentes de IA que trabajan en Flowtify. Cada skill es un "plugin" que inyecta conocimiento especializado.

## 📖 Orden de Lectura Recomendado

Lee en este orden para construir conocimiento de forma incremental:

| # | Skill | Archivo | Categoría | Descripción |
|:--|:---|:---|:---|:---|
| 1 | **Tokenizer** | [`Tokenizer.md`](./Tokenizer.md) | `guardián` | Enforce del Design System. Zero-tolerance policy para violations. 5 dimensiones de análisis. |
| 2 | **Cognitive Typographer** | [`COGNITIVE-TYPOGRAPHER.md`](./COGNITIVE-TYPOGRAPHER.md) | `tipografía` | Ritmo tipográfico: tracking, text-wrap, medida óptima de línea, unidades rem. |
| 3 | **Hardware Symphony** | [`HARDWARE-SYMPHONY.md`](./HARDWARE-SYMPHONY.md) | `performance` | 60fps protocol. Smart Shutdown, elegant degradation, legal animated properties. |
| 4 | **Debug Panel Architect** | [`DEBUG-PANEL-ARCHITECT.md`](./DEBUG-PANEL-ARCHITECT.md) | `workflow` | **v2.0 Pro.** Collapsible pill UI, tabbed controls, 8 control types, context-aware detection, Tailwind-ready copy, 9-step purge checklist. |
| 5 | **Creative Direction** | [`CREATIVE-DIRECTION.md`](./CREATIVE-DIRECTION.md) | `diseño` | Anti-"AI Slop". Dirección de arte premium para Flowtify. |
| 6 | **Creative Motion** | [`CREATIVE-MOTION.md`](./CREATIVE-MOTION.md) | `animación` | Filosofía Awwwards: scroll pin, liquid cursor, scrollytelling, parallax. |
| 7 | **Awwwards Motion** | [`AWWWARDS-MOTION.md`](./AWWWARDS-MOTION.md) | `animación` | Físicas de scroll: Layered Unveiling, Water Mask, Breathing Canvas. |
| 8 | **Cinematic Architect** | [`CINEMATIC-ARCHITECT.md`](./CINEMATIC-ARCHITECT.md) | `narrativa` | Narrativa visual DOM-3D: Diegetic UI, Sandwich Technique, Tunnel Transition. |
| 9 | **Scroll Effects Architect** | [`SCROLL-EFFECTS-ARCHITECT.md`](./SCROLL-EFFECTS-ARCHITECT.md) | `referencia` | 7 técnicas GSAP avanzadas con código completo (815 líneas). |

## 🏷️ Categorías

- **`guardián`** — Enforce de reglas y auditoría
- **`tipografía`** — Texto, fuentes, legibilidad
- **`performance`** — Optimización y 60fps
- **`workflow`** — Procesos de trabajo
- **`diseño`** — Dirección creativa y estética
- **`animación`** — Motion design y GSAP
- **`narrativa`** — Experiencias cinematográficas
- **`referencia`** — Código de referencia y snippets
