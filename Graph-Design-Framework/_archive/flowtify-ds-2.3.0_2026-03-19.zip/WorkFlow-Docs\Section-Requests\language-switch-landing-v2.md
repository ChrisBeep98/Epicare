# 🌐 Language Switch — Migración i18n del Landing V2

> **Fecha:** 25 de Febrero, 2026  
> **Componentes afectados:** `Header.tsx`, `LiquidHero.tsx`, `HeroChatAnimation.tsx`  
> **Estado:** ✅ Implementado y funcional

---

## ¿Qué se hizo?

Se añadió soporte de cambio de idioma (EN/ES) a tres componentes del nuevo landing (V2), reutilizando la infraestructura `next-intl` que **ya existía** en el proyecto para los paneles Admin/Client.

### Componentes migrados

| Componente | Ruta | Textos internacionalizados |
|:---|:---|:---|
| **Header V2** | `src/components/landing-v2/header/Header.tsx` | Nav labels (Product, Solutions...), Login CTA, menú móvil |
| **LiquidHero** | `src/components/landing-v2/hero/LiquidHero.tsx` | H1, subtítulo, CTAs, trust badge, modal |
| **HeroChatAnimation** | `src/components/landing-v2/hero/HeroChatAnimation.tsx` | Chat bubbles Acto 1 (Med Spa) y Acto 2 (Fashion) |

### Toggle de idioma en el Header

Se creó un componente `LanguageToggle` inline dentro de `Header.tsx` que:
- Usa `useLocale()` de `next-intl` para leer el idioma actual
- Usa `setUserLocale()` de `@/i18n/locale` para escribir la cookie `NEXT_LOCALE`
- Muestra un toggle minimal `EN / ES` que se adapta al modo dark/light del header
- Ubicado a la izquierda del botón Login en desktop

---

## ¿Qué NO se tocó?

> [!IMPORTANT]
> Esta migración es **quirúrgica**. Solo toca los tres componentes listados arriba.

- ❌ **No se modificó** ningún componente de Admin/Client panel
- ❌ **No se renombraron ni eliminaron** keys existentes en `messages/en.json` o `messages/es.json`
- ❌ **No se modificaron** otros componentes del landing V2 (ServicesBento, FlowExplanation, ComparisonSection, WaveRevealSection, etc.)
- ❌ **No se cambió** la configuración i18n (`config.ts`, `locale.ts`, `request.ts`)
- ❌ **No se cambió** el `layout.tsx` ni el `NextIntlClientProvider`

---

## Arquitectura i18n utilizada

```
messages/
├── en.json   ← Se añadió namespace "landingV2" al final
└── es.json   ← Se añadió namespace "landingV2" al final

src/i18n/
├── config.ts    ← Sin cambios (locales: ['en', 'es'], default: 'en')
├── locale.ts    ← Sin cambios (cookie NEXT_LOCALE)
└── request.ts   ← Sin cambios (carga dinámica de JSON)
```

### Namespace `landingV2`

Toda la estructura nueva está bajo un namespace propio para **no contaminar** los namespaces existentes:

```json
{
  "landingV2": {
    "header": { ... },   // 10 keys
    "hero": { ... },      // 12 keys
    "chat": { ... }       // 16 keys
  }
}
```

### Cómo se usa en componentes

```tsx
// En Header.tsx
const t = useTranslations('landingV2.header');
// → t('product'), t('login'), t('mobileMenuSistemas')

// En LiquidHero.tsx
const t = useTranslations('landingV2.hero');
// → t('titleLine1'), t('ctaPrimary'), t('modalTitle')

// En HeroChatAnimation.tsx
const t = useTranslations('landingV2.chat');
// → t('act1_client1'), t('act2_flow1'), t('act2_chip1')
```

---

## Regla para futuros componentes del Landing V2

Cuando se decida internacionalizar otro componente del landing V2:

1. Crear un nuevo sub-namespace dentro de `landingV2` (ej: `"servicesBento": { ... }`)
2. Añadir las keys a **AMBOS** archivos JSON (`en.json` y `es.json`)
3. Importar `useTranslations` en el componente
4. Reemplazar texto hardcoded por `t('key')`
5. **Nunca tocar** namespaces existentes (`admin`, `client`, `common`, etc.)
