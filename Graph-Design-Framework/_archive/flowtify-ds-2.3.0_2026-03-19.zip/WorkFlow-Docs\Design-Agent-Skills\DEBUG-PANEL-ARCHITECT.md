---
name: Debug Panel Architect
description: "Level 2 (Pro) skill for creating temporary, zero-trace live testing UIs. Features: collapsible pill UI, tabbed controls, 8 control types, context-aware element detection, responsive dual-breakpoint testing, Tailwind-ready clipboard export, and formal purge checklist."
---

# 🛠 DEBUG PANEL ARCHITECT v2.0: The Zero-Trace Live Tester

## Contexto & Filosofía
A veces, adivinar valores de CSS (como `mix-blend-mode`), ritmos de animación, o **decidir entre arquitecturas de layout completas** requiere construir y recompilar docenas de veces. Esto es lento y frustrante para el usuario. 

La solución de Flowtify es la **inyección de Paneles de Debug en Vivo (A/B Testers Temporales)**. Esta skill te instruye sobre cómo construir un panel flotante temporal sobre cualquier componente React para que el usuario pueda manipular configuraciones al instante.

**CRÍTICO:** Estos paneles son estrictamente para desarrollo. **NUNCA** deben llegar a producción. Respetan el ciclo de vida de **3 Fases Flowtify**, permitiendo su eliminación quirúrgica total (*zero-trace*).

---

## 📅 El Ciclo de Vida de 3 Fases (The Flowtify Standard)

### Fase 1: Prueba de Concepto (Live Testing)
Inyección del panel UI flotante con estados temporales para alternar valores CSS o estructuras JSX completas. El código se asume "sucio". El objetivo: que el usuario juegue con su pantalla y tome decisiones.

### Fase 2: Tokenización y Consolidación (The Refactor)
El usuario elige un ganador. El Agente transfiere "en piedra" el código ganador aplicando los estándares Flowtify (`landing.css`, tokens del Design System, variables CSS semánticas).

### Fase 3: The Purge (Zero-Trace Cleanup)
Eliminación quirúrgica total. Ver la **Purge Checklist** al final de este documento.

---

## 🧠 PROTOCOLO DE DETECCIÓN CONTEXTUAL

**ANTES de construir el panel**, el Agente DEBE ejecutar este análisis del componente objetivo:

### Paso 1: Inventario de Elementos
Escanear el componente y clasificar CADA elemento visual en una de estas categorías:

| Categoría | Ejemplos | Controles que genera |
|:---|:---|:---|
| **Texto** | H1, H2, subtítulos, párrafos, overlines | Font size, weight, color, tracking, opacity |
| **Imágenes/Video** | `<img>`, `<video>`, backgrounds | Scale, objectPosition (X/Y), objectFit, mask, opacity |
| **Contenedores** | Wrappers, cards, secciones | Padding, gap, border-radius, background, blur |
| **Elementos Flotantes** | Chips, badges, burbujas, botones CTA | Position (X/Y), scale, rotation, opacity, z-index |
| **Animaciones** | GSAP timelines, transitions | Duration, delay, ease, stagger, distance |
| **Layout** | Grid/Flex containers | Direction, align, justify, columns, wrap |

### Paso 2: Agrupar en Tabs
Los controles se organizan en **tabs lógicas** según la anatomía de la sección:

```
Tab 1: "Layout"     → Containers, grids, spacing, responsive switches
Tab 2: "Visuals"    → Colors, blend modes, opacity, backgrounds, borders
Tab 3: "Elements"   → Position/scale de elementos flotantes (chips, imágenes)
Tab 4: "Motion"     → Duración, ease, delay de animaciones GSAP
```

> **Regla:** Máximo 4 tabs. Si hay menos categorías de elementos, usar menos tabs. El panel debe ser utilizable, no abrumador.

### Paso 3: Nombrar el Panel
El título del panel debe reflejar el componente: `🧪 ComparisonSection Debug`, `🧪 FlowSellHero Debug`, etc.

---

## 🎛️ LIBRERÍA DE CONTROLES (Control Types)

El Agente debe usar estos tipos de controles estandarizados. Cada uno tiene su patrón de implementación exacto:

### 1. `slider` — Valor Numérico
Para: escala, opacidad, posición, tamaño, duración.
```tsx
{/* ── Slider: Escala de Imagen ── */}
<label className="flex items-center justify-between">
  <span className="text-white/60">Scale</span>
  <span className="text-flowtify-cyan font-mono">{imgScale.toFixed(2)}</span>
</label>
<input
  type="range" min={0.5} max={2} step={0.01}
  value={imgScale}
  onChange={(e) => setImgScale(parseFloat(e.target.value))}
  className="w-full h-1 bg-white/20 rounded-full appearance-none cursor-pointer
             [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3
             [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:rounded-full
             [&::-webkit-slider-thumb]:bg-flowtify-cyan"
/>
```

### 2. `color` — Color Picker
Para: backgrounds, bordes, text colors.
```tsx
{/* ── Color: Background ── */}
<label className="flex items-center justify-between">
  <span className="text-white/60">BG Color</span>
  <div className="flex items-center gap-2">
    <input type="color" value={bgColor}
      onChange={(e) => setBgColor(e.target.value)}
      className="w-6 h-6 rounded border border-white/20 cursor-pointer bg-transparent"
    />
    <span className="text-white/40 font-mono text-[10px]">{bgColor}</span>
  </div>
</label>
```

### 3. `select` — Dropdown de Opciones
Para: blend modes, font weights, easing functions, layout modes.
```tsx
{/* ── Select: Blend Mode ── */}
<label className="flex items-center justify-between">
  <span className="text-white/60">Blend</span>
  <select value={blend} onChange={(e) => setBlend(e.target.value)}
    className="bg-white/10 border border-white/20 rounded px-2 py-0.5 text-white text-[11px]">
    {["normal","multiply","screen","overlay","difference"].map(m => (
      <option key={m} value={m} className="bg-black">{m}</option>
    ))}
  </select>
</label>
```

### 4. `toggle` — Boolean On/Off
Para: show/hide elementos, enable/disable animaciones.
```tsx
{/* ── Toggle: Mostrar Chips ── */}
<button onClick={() => setShowChips(!showChips)}
  className={`px-3 py-1 rounded-full text-[11px] font-medium transition-colors ${
    showChips ? 'bg-flowtify-cyan text-black' : 'bg-white/10 text-white/50'
  }`}>
  {showChips ? '● Chips ON' : '○ Chips OFF'}
</button>
```

### 5. `position` — Dual X/Y
Para: posicionar elementos flotantes con precisión.
```tsx
{/* ── Position: Chip 1 ── */}
<div className="space-y-1">
  <span className="text-white/60 text-[10px]">Chip 1 Position</span>
  <div className="grid grid-cols-2 gap-2">
    <label className="flex items-center gap-1">
      <span className="text-white/40 text-[10px]">X</span>
      <input type="range" min={-20} max={120} step={1} value={chip1X}
        onChange={(e) => setChip1X(parseInt(e.target.value))}
        className="w-full h-1 bg-white/20 rounded-full appearance-none
                   [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-2
                   [&::-webkit-slider-thumb]:h-2 [&::-webkit-slider-thumb]:rounded-full
                   [&::-webkit-slider-thumb]:bg-flowtify-cyan" />
      <span className="text-flowtify-cyan font-mono text-[10px] w-8 text-right">{chip1X}%</span>
    </label>
    <label className="flex items-center gap-1">
      <span className="text-white/40 text-[10px]">Y</span>
      <input type="range" min={-20} max={120} step={1} value={chip1Y}
        onChange={(e) => setChip1Y(parseInt(e.target.value))}
        className="w-full h-1 bg-white/20 rounded-full appearance-none
                   [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-2
                   [&::-webkit-slider-thumb]:h-2 [&::-webkit-slider-thumb]:rounded-full
                   [&::-webkit-slider-thumb]:bg-flowtify-cyan" />
      <span className="text-flowtify-cyan font-mono text-[10px] w-8 text-right">{chip1Y}%</span>
    </label>
  </div>
</div>
```

### 6. `breakpoint` — Mobile/Desktop Toggle
Para: ver y editar valores de ambos breakpoints simultáneamente.
```tsx
{/* ── Breakpoint Switch ── */}
<div className="flex gap-1 p-0.5 bg-white/5 rounded-lg">
  <button onClick={() => setBp('mobile')}
    className={`px-3 py-1 rounded-md text-[11px] transition-colors ${
      bp === 'mobile' ? 'bg-flowtify-cyan text-black font-bold' : 'text-white/50'
    }`}>📱 Mobile</button>
  <button onClick={() => setBp('desktop')}
    className={`px-3 py-1 rounded-md text-[11px] transition-colors ${
      bp === 'desktop' ? 'bg-flowtify-cyan text-black font-bold' : 'text-white/50'
    }`}>🖥 Desktop</button>
</div>
```

### 7. `preset` — Guardar/Cargar Configuraciones
Para: guardar combinaciones de valores en localStorage y restaurarlas.
```tsx
{/* ── Presets ── */}
<div className="flex gap-1 flex-wrap">
  <button onClick={() => {
    localStorage.setItem('debug-preset-A', JSON.stringify(getAllValues()));
  }} className="px-2 py-0.5 bg-white/10 rounded text-[10px] text-white/60 hover:bg-white/20">
    💾 Save A
  </button>
  <button onClick={() => {
    const data = localStorage.getItem('debug-preset-A');
    if (data) applyValues(JSON.parse(data));
  }} className="px-2 py-0.5 bg-white/10 rounded text-[10px] text-white/60 hover:bg-white/20">
    📂 Load A
  </button>
</div>
```

### 8. `section-separator` — Separador Visual
Para: separar bloques lógicos dentro de un tab.
```tsx
<div className="border-t border-white/10 my-3" />
<span className="text-[9px] text-white/30 uppercase tracking-widest">Floating Elements</span>
```

---

## 🏗️ ARQUITECTURA DEL PANEL (UI Specification)

### El Panel Colapsable (La "Pill")

El panel tiene **2 estados**: colapsado (pill mínima) y expandido (panel completo).

```tsx
// ==========================================
// 🧪 INICIALIZA: TEMPORARY DEBUG TESTER STATE 
// ==========================================
const [__dbgOpen, __setDbgOpen] = useState(false);
const [__dbgTab, __setDbgTab] = useState(0);
// ... todos los controles de valores aquí ...
// ==========================================
// 🛑 TERMINA: TEMPORARY DEBUG TESTER STATE 
// ==========================================
```

```tsx
{/* ========================================== */}
{/* 🧪 INICIALIZA: TEMPORARY DEBUG UI PANEL    */}
{/* ========================================== */}

{/* ── Estado Colapsado: Pill Mínima ── */}
{!__dbgOpen && (
  <button
    onClick={() => __setDbgOpen(true)}
    className="fixed bottom-3 right-3 z-[9999] px-3 py-1.5
               bg-black/80 backdrop-blur-xl rounded-full
               border border-white/15 text-white/70 text-[11px]
               font-medium shadow-[0_0_20px_rgba(0,180,255,0.15)]
               hover:bg-black/90 hover:text-white hover:border-flowtify-cyan/40
               transition-all duration-200 flex items-center gap-1.5"
  >
    🧪 <span className="hidden sm:inline">Debug</span>
  </button>
)}

{/* ── Estado Expandido: Panel Completo ── */}
{__dbgOpen && (
  <div className="fixed bottom-3 right-3 z-[9999] w-[340px] max-h-[80vh]
                  bg-black/92 backdrop-blur-2xl rounded-2xl
                  border border-white/15 text-white text-[11px]
                  shadow-[0_0_60px_rgba(0,180,255,0.12)]
                  flex flex-col overflow-hidden">

    {/* ── Header ── */}
    <div className="flex items-center justify-between px-4 py-2.5
                    border-b border-white/10 shrink-0">
      <span className="font-bold text-flowtify-cyan text-[13px]">
        🧪 SectionName Debug
      </span>
      <div className="flex items-center gap-1">
        {/* Copy All Values */}
        <button
          onClick={() => {
            const values = { /* ALL useState values here */ };
            const tailwind = Object.entries(values)
              .map(([k, v]) => `${k}: ${v}`)
              .join('\n');
            navigator.clipboard.writeText(tailwind);
          }}
          className="px-2 py-0.5 bg-white/10 rounded text-[10px]
                     text-white/60 hover:bg-flowtify-cyan/20 hover:text-flowtify-cyan
                     transition-colors"
        >
          📋 Copy
        </button>
        {/* Close */}
        <button
          onClick={() => __setDbgOpen(false)}
          className="w-6 h-6 flex items-center justify-center rounded-full
                     bg-white/10 text-white/60 hover:bg-red-500/30
                     hover:text-red-400 transition-colors text-[13px]"
        >
          ✕
        </button>
      </div>
    </div>

    {/* ── Tab Bar ── */}
    <div className="flex gap-0.5 px-3 py-2 border-b border-white/5 shrink-0">
      {['Layout', 'Visuals', 'Elements', 'Motion'].map((tab, i) => (
        <button key={tab}
          onClick={() => __setDbgTab(i)}
          className={`px-3 py-1 rounded-lg text-[10px] font-medium transition-colors ${
            __dbgTab === i
              ? 'bg-flowtify-cyan/20 text-flowtify-cyan'
              : 'text-white/40 hover:text-white/70 hover:bg-white/5'
          }`}
        >
          {tab}
        </button>
      ))}
    </div>

    {/* ── Content Area (Scrollable) ── */}
    <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3
                    scrollbar-thin scrollbar-thumb-white/10">
      
      {/* Tab 0: Layout controls */}
      {__dbgTab === 0 && (
        <div className="space-y-3">
          {/* ... slider, select, toggle controls here ... */}
        </div>
      )}

      {/* Tab 1: Visuals controls */}
      {__dbgTab === 1 && (
        <div className="space-y-3">
          {/* ... color, blend, opacity controls here ... */}
        </div>
      )}

      {/* Tab 2: Elements controls */}
      {__dbgTab === 2 && (
        <div className="space-y-3">
          {/* ... position, scale controls here ... */}
        </div>
      )}

      {/* Tab 3: Motion controls */}
      {__dbgTab === 3 && (
        <div className="space-y-3">
          {/* ... duration, ease, stagger controls here ... */}
        </div>
      )}
    </div>
  </div>
)}

{/* ========================================== */}
{/* 🛑 TERMINA: TEMPORARY DEBUG UI PANEL       */}
{/* ========================================== */}
```

---

## 📋 COPY VALUES V2: Tailwind-Ready Export

El botón "📋 Copy" **NO** debe copiar JSON crudo. Debe copiar en formato **legible y paste-ready**:

```
── 🧪 ComparisonSection Debug ──
Tab: Layout
  containerPadding: pt-[120px] md:pt-[160px]
  gap: gap-6 md:gap-10
Tab: Visuals
  act1Blend: mix-blend-multiply
  overlayOpacity: 0.35
Tab: Elements
  chip1: top-[5%] left-[8%] md:top-[10%] md:left-[12%]
  chip2: bottom-[3%] right-[5%] md:bottom-[8%] md:right-[10%]
  imgScale: scale-[1.13] md:scale-[1.27]
Tab: Motion
  revealDuration: 1.4s
  revealEase: power4.out
  chipStagger: 0.15s
```

> **Regla:** Los valores de posición/escala deben incluir AMBOS breakpoints (mobile y desktop) si el panel tiene breakpoint toggle.

---

## 🚨 DELIMITACIÓN ESTRICTA (The Sandbox)

### Regla de Prefijo `__dbg`
TODOS los estados temporales del debug panel deben usar el prefijo `__dbg` para facilitar la búsqueda y purga:
```tsx
const [__dbgOpen, __setDbgOpen] = useState(false);
const [__dbgTab, __setDbgTab] = useState(0);
const [__dbgScale, __setDbgScale] = useState(1.0);
const [__dbgChip1X, __setDbgChip1X] = useState(10);
```

### Comentarios de Bloqueo Inmutables
```tsx
// ==========================================
// 🧪 INICIALIZA: TEMPORARY DEBUG TESTER STATE 
// ==========================================
// ... todos los useState con prefijo __dbg ...
// ==========================================
// 🛑 TERMINA: TEMPORARY DEBUG TESTER STATE 
// ==========================================
```

```tsx
{/* ========================================== */}
{/* 🧪 INICIALIZA: TEMPORARY DEBUG UI PANEL    */}
{/* ========================================== */}
{/* ... todo el JSX del panel ... */}
{/* ========================================== */}
{/* 🛑 TERMINA: TEMPORARY DEBUG UI PANEL       */}
{/* ========================================== */}
```

### Regla de Componentización para Pruebas Masivas
Si la prueba estructural es grande (>100 líneas de JSX), crear las variaciones como variables locales dentro del bloque `DEBUG TESTER STATE`:
```tsx
// Dentro del bloque 🧪:
const __dbgLayoutA = (
  <div className="flex flex-col">{/* ... */}</div>
);
const __dbgLayoutB = (
  <div className="grid grid-cols-2">{/* ... */}</div>
);
```

---

## 🧹 PURGE CHECKLIST (Fase 3: Zero-Trace)

Cuando el usuario apruebe los valores finales, el Agente **DEBE** ejecutar esta checklist en orden:

```markdown
## Purge Checklist — [ComponentName]

- [ ] 1. **Hardcodear valores ganadores:** Transferir TODOS los valores del "📋 Copy" 
         a clases Tailwind/CSS definitivas en el componente.
- [ ] 2. **Eliminar bloque STATE:** Borrar TODO entre los comentarios 
         `🧪 INICIALIZA: TEMPORARY DEBUG TESTER STATE` y `🛑 TERMINA`.
- [ ] 3. **Eliminar bloque UI:** Borrar TODO entre los comentarios 
         `🧪 INICIALIZA: TEMPORARY DEBUG UI PANEL` y `🛑 TERMINA`.
- [ ] 4. **Eliminar layouts perdedores:** Si había variaciones `__dbgLayoutA`/`B`, 
         borrar la no elegida.
- [ ] 5. **Limpiar imports huérfanos:** Si `useState` ya no se usa en el componente, 
         removerlo del import de React.
- [ ] 6. **Limpiar localStorage:** Si se usaron presets, ejecutar 
         `localStorage.removeItem('debug-preset-*')` o borrar manualmente.
- [ ] 7. **Buscar residuos:** Grep `__dbg` en el archivo. Resultado esperado: 0 matches.
- [ ] 8. **Verificar render:** El componente debe verse IDÉNTICO a como se veía 
         con los valores elegidos en el panel.
- [ ] 9. **Build check:** `pnpm build` sin errores TypeScript.
```

> **Regla de Oro:** Después de la purga, el archivo debe parecer como si el Debug Panel **nunca hubiera existido**. Cero rastro. Cero comentarios residuales. Cero useState sin usar.
