# Testimonials Carousel
> Última actualización: 19 de Marzo, 2026

> **TL;DR:** Carrusel de testimonios con social proof river horizontal. Auto-scroll con pause on hover. Cards con avatar, nombre, y quote.

## Componentes
- `src/components/landing-v2/TestimonialsCarousel.tsx` — Carrusel principal

## Estado Actual
- Funcional con animación de scroll infinito horizontal.

## Historial de Cambios
- *Se poblará conforme se trabaje en esta sección.*

## Decisiones de Diseño
- *Pendiente de documentar.*

## Bugs Conocidos / Pendientes
- Ninguno conocido.
