# Prompt de Actualización de Contexto

Copia y pega este prompt en tus futuras interacciones conmigo (Gemini) cada vez que terminemos un hito importante, agreguemos una librería, o cambiemos un flujo en el proyecto. Esto me obligará a leer el estado actual y agregar el nuevo conocimiento al archivo `context.md` sin perder el historial.

***

**PROMPT PARA ACTUALIZAR EL CONTEXTO:**

> "Hola Gemini. Acabamos de completar una nueva fase en el proyecto. Por favor, realiza las siguientes acciones:
> 
> 1. Lee el archivo actual en `context-Docs/project-context/context.md` para entender dónde nos quedamos.
> 2. Analiza el último trabajo que acabamos de hacer (archivos creados, bugs solucionados, dependencias instaladas o cambios en la arquitectura).
> 3. Sobrescribe y actualiza el archivo `context.md`. **No borres la información fundacional**, pero añade una nueva sección o punto bajo 'Registro de Acciones Críticas' o 'Estructura de la Migración' detallando lo nuevo que hicimos. 
> 4. Actualiza la fecha de 'Última Actualización' y cambia el 'Estado' si hemos avanzado a una nueva fase.
> 5. Al terminar, confírmame con un mensaje breve enumerando los viñetas exactas que agregaste al documento."

***
