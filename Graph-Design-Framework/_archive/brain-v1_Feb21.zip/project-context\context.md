# Contexto del Proyecto: Flowtify Landing Page Redesign
> **Última Actualización:** 21 de Febrero, 2026
> **Estado:** Fase 1 (Integración y Pruebas Iniciales)

## 1. Visión General
El objetivo de este esfuerzo es realizar un **rediseño completo de la página de inicio (Landing Page)** del proyecto `website-flowtify`. El proyecto original es una aplicación web robusta construida con Next.js (App Router), React 19, Supabase y Prisma, incluyendo paneles de administración protegidos.

Para lograr el rediseño sin afectar la aplicación en producción, se está implementando una migración quirúrgica desde otro repositorio ("Web") hacia una ruta de pruebas (`/inicio-nuevo`) antes del reemplazo oficial.

## 2. Entorno y Stack Tecnológico
- **Framework Principal:** Next.js 16.1.4 (Turbopack)
- **Gestión de Estilos:** Tailwind CSS v4 (vía PostCSS) integrado en `src/app/globals.css`.
- **Librerías de UI Migradas:** `framer-motion` (v12.x), `gsap` (v3.14.x) y `lenis` (smooth scrolling).
- **Control de Versiones:** Git (Rama actual: `feature/redesign-landing`)
- **Gestor de Paquetes:** `pnpm` (Estrictamente configurado).

## 3. Estructura de la Migración
Los componentes del nuevo diseño han sido copiados bajo una estructura segura para evitar choques:
- **Componentes V2:** `src/components/landing-v2/` (Incluye `LiquidHero`, `ScrollSequence`, `ModulesCarousel`, etc.)
- **Assets Públicos:** `public/hero-sequence/*` y fuentes importadas en layout.
- **Ruta de Aislamiento:** `src/app/inicio-nuevo/page.tsx` (Ruta no protegida por el Middleware de Supabase para desarrollo).
- **Estilos Comunes:** Todas las variables `--color-pillar-*` y configuraciones CSS como `--animate-gradient-flow`, `.liquid-glass`, `.liquid-text-texture` se adjuntaron a la parte final del archivo original `globals.css`.

## 4. Registro de Acciones Críticas Realizadas
1. **Configuración del Repositorio:** Se solucionó el problema del archivo zip y se conectó el proyecto mediante `git clone` oficial al repositorio `flowtifyai/website-flowtify`.
2. **Corrección de Dependencias:** Se arregló la corrupción iniciada por `npm install` limpiando el árbol de dependencias e instalando exclusivamete con `pnpm`, agregando `gsap` y `lenis`.
3. **Resolución de Conflictos de Next.js (Supabase):** Se inyectaron credenciales falsas (`NEXT_PUBLIC_SUPABASE_URL` y `NEXT_PUBLIC_SUPABASE_ANON_KEY` en `.env.local`) y se añadió `/inicio-nuevo` a las rutas del middleware público para evitar crasheos 500 por la protección de sesiones activas. 
4. **Corrección de Meta-datos Next.js:** Se arregló el Warning de `viewport` sacándolo de la variable `metadata` en el documento `src/app/layout.tsx`.

## 5. Próximos Pasos (To-Do)
- Validar visualmente la página de pruebas (`http://localhost:3000/inicio-nuevo`).
- Ajustar cualquier discrepancia de estilos entre el Tailwind original y el rediseño.
- Configurar adecuadamente la importación de fuentes si existen fuentes locales nuevas no declaradas.
- Una vez finalizado y probado, reemplazar el contenido general de `src/app/page.tsx` por el contenido de `inicio-nuevo`.
