# 🧠 Agent Skill: THE COGNITIVE TYPOGRAPHER (Rhythm & Adaptive Reading)

**Level:** Editorial / Master-Class
**Objective:** Elevate typography from "looking good" to "breathing with the user." In Flowtify AI, reading must be an effortless, immersive experience.

---

> *"Good typography is invisible. Outstanding typography is a silent rhythm that guides the mind."*

This skill defines the strict rules for text orchestration. The `Tokenizer.md` handles the *sizes*, but this skill handles the *behavior* and *micro-aesthetics* of the text.

Whenever you build a UI component involving reading (Headings, Paragraphs, Articles, Features), you MUST follow these Cognitive Typography laws:

## 1. THE LAWS OF TRACKING (Letter-Spacing)
Text density alters perception. You must mathematically adjust letter-spacing based on font size and weight.

*   **Massive Display Headlines (H1s > 4rem):** MUST use negative tracking (e.g., `tracking-tighter` or `letter-spacing: -0.04em`). The letters must feel like a unified, solid object.
*   **Subheadings & Overlines (Small caps):** MUST use positive tracking (e.g., `tracking-widest` or `letter-spacing: 0.1em`). Uppercase tiny text needs air to be legible.
*   **Body Text (Paragraphs):** Natural or slightly relaxed (e.g., `tracking-normal` to `letter-spacing: 0.01em`). Never compress body text.

## 2. ORCHESTRATED LINE BREAKS (Text Wrapping)
Never let the browser randomly chop your elegant sentences.

*   **Headlines (H1, H2, H3):** MUST use `text-wrap: balance` (Tailwind: `text-balance`). This prevents awkward long lines with one single word hanging on the next line.
*   **Paragraphs (Body):** MUST use `text-wrap: pretty` (Tailwind: `text-pretty`). This eliminates "Typographic Orphans" (a single word left alone on the last line of a paragraph).

## 3. ADAPTIVE RHYTHM (Fluid Typography)
Do not rely solely on standard media query breakpoints for typography sizing. Text must scale liquidly.

*   **Implementation:** Prefer CSS `clamp()` for critical headings.
    *   *Example:* `font-size: clamp(2.5rem, 5vw + 1rem, 5rem);` ensures the title never breaks layouts on small screens, gracefully expanding until it hits its maximum.

## 4. THE LAW OF MEASURE (Optimal Line Length)
The human eye gets fatigued if lines are too long or too short.
*   **Paragraphs:** Constrain the maximum width of reading blocks to roughly 65-75 characters.
*   **Implementation:** Wrap body text in `max-w-prose` or explicitly limit the width of the container (`max-w-2xl`). Do not let a paragraph span 100% of a 1920px screen.

## 🤖 AI PROMPT DIRECTIVES
When generating text structures for Flowtify:
1. *"Did I leave the H1 with default tracking? If yes, tighten it to make it lock together."*
2. *"Is the paragraph allowed to stretch infinitely? If yes, apply `max-w-prose`."*
3. *"Did I just write a multi-line headline? If yes, apply `text-balance`."*
