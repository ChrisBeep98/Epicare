# Prompt de Respaldo de Cerebro (Brain Backup)

Copia y pega este prompt en tus futuras interacciones conmigo (Gemini) cada vez que quieras guardar una "Instantánea" o versión segura de todas nuestras reglas, habilidades y contexto en la carpeta `context-Docs`.

***

**PROMPT PARA RESPALDAR EL CEREBRO:**

> "Hola Gemini. Hemos hecho mejoras increíbles a tus Habilidades de Agente hoy. Por favor, crea un respaldo (Backup) de tu cerebro actual siguiendo estos pasos exactos:
> 
> 1. Abre tu terminal de **PowerShell**.
> 2. Ejecuta el comando para crear un archivo ZIP de todo lo que hay dentro de `context-Docs`, pero **EXCLUYENDO** la carpeta `_archive`. 
> 3. El comando exacto que debes ejecutar es: 
>   `Get-ChildItem -Path "d:/Proyectos-Importantes/Flowtify/Production-Web/context-Docs" -Exclude "_archive" | Compress-Archive -DestinationPath "d:/Proyectos-Importantes/Flowtify/Production-Web/context-Docs/_archive/brain-vX_MES_DIA.zip" -Force`
> 4. Asegúrate de reemplazar `vX` por el siguiente número de versión lógico, y `MES_DIA` por la fecha de hoy.
> 5. Una vez que el ZIP se cree exitosamente, confírmame el nombre exacto del archivo que acabas de guardar en la bóveda."

***
