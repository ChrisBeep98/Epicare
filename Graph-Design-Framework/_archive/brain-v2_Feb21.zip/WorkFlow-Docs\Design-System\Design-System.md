# FLOWTIFY AI // DESIGN SYSTEM & TOKENS

Este archivo es la **Única Fuente de Verdad (Single Source of Truth)**. Define la jerarquía visual que debe estar sincronizada con `app-v1/app/globals.css`.

---

## 🛠️ IMPLEMENTACIÓN TÉCNICA
- **Ubicación de Variables:** `app-v1/app/globals.css`
- **Metodología:** Tailwind v4 (@theme inline + @utility)

---

## 🖼️ 1. MARCOS Y MÁRGENES (The Page Frame)
Usa siempre la variable `--spacing-frame` para consistencia.

| Dispositivo | Valor Real | Clase CSS |
| :--- | :--- | :--- |
| **Móvil** | **12px** | `px-frame` |
| **Tablet** | **32px** | `px-frame` |
| Desktop | 96px | `px-frame` |

---

## 📏 1.2 ESPACIADO VERTICAL (Section Padding)
Define el **ritmo vertical** entre bloques de contenido.

| Escenario | Espacio Total Deseado | Clase CSS |
| :--- | :--- | :--- |
| **Móvil** | **80px** | `.section-v-spacing` |
| **Desktop** | **160px** | `.section-v-spacing` |

---

## 📐 2. TYPOGRAPHY TOKENS (Semánticos & Cognitivos)

> **Regla de Oro (Cognitive Typographer):** Nunca usar anchos infinitos. Los títulos usan `text-balance`, los párrafos usan `text-pretty` y máximo `max-w-prose` (o equivalente).
> **Fuentes Premium:** Usar **Outfit** estrictamente para titulares/Display, y **GT Walsheim Pro** (o similar sans geométrica premium) para texto de lectura y cuerpo.

| Token | Clase CSS | Estilos Base | Regla Cognitiva (Tracking/Wrap) |
| :--- | :--- | :--- | :--- |
| **H-HERO-DISPLAY** | `.text-h-hero` | `text-5xl md:text-7xl lg:text-8xl font-bold text-foreground` | `tracking-tighter` + `text-balance` |
| **H-SECTION** | `.text-h-section` | `text-3xl md:text-5xl font-semibold text-foreground` | `tracking-tight` + `text-balance` |
| **UI-LABEL** | `.text-ui-label` | `font-medium text-[13px] text-muted-foreground uppercase` | `tracking-widest` |
| **NUM-DATA** | `.text-data` | `font-mono font-bold text-primary` | `tracking-tight` |
| **TEXT-BODY** | `.text-body` | `text-base text-muted-foreground leading-relaxed` | `tracking-normal` + `text-pretty` + `max-w-2xl` |

### 2.1 Ritmo Fluido (CSS Locks si es necesario)
Para los titulares principales, si las clases de Tailwind (`md:`, `lg:`) no son suficientemente suaves, el token `text-h-hero` debe implementarse en CSS usando `clamp()`:
```css
.text-h-hero {
  font-size: clamp(3rem, 8vw, 6rem);
  line-height: 1.1;
}
```

---

## 🎨 3. COLOR PALETTE & MODES

### 3.0 FILOSOFÍA ATMOSFÉRICA (The Mood Direction)
- **⚡ VIBRANT ENERGY (Light Mode):** Direccionalidad hacia la claridad y el futuro. Evoca confianza, tecnología invisible y optimismo.
- **🚫 DARK MODE:** Desactivado completamente. La marca vive en la luz.
- **GLASSMORPHISM:** El material principal es el cristal blanco translúcido sobre fondos sutiles.

### 3.1 NÚCLEO ATMOSFÉRICO (Semantic Mapping)

| Variable CSS | Token Tailwind | Value (Light Mode Only) ☀️ | Uso |
| :--- | :--- | :--- | :--- |
| `--background` | `bg-background` | `#FFFFFF` (Pure White) | Lienzo principal |
| `--secondary-bg`| `bg-secondary` | `#F2F2F7` (Ghost) | Fondos alternativos / Secciones |
| `--foreground` | `text-foreground` | `#1D1D1F` (Off Black) | Texto principal |
| `--muted` | `text-muted` | `#6B7280` (Gray 500) | Textos secundarios |
| `--border` | `border-border` | `#E2E8F0` (Alice Blue/Gris) | Líneas divisorias |
| `--glass` | `bg-glass` | `rgba(255,255,255,0.7)` | Fondos con backdrop-blur |

### 3.1.5 Colores de Sistema (Feedback)
- **Success:** `#00D9A3` (Vivid)
- **Warning:** `#FB923C` (Vivid)
- **Error:** `#FF2D55` (Vivid)

### 3.2 BRAND ACCENTS (The 4-Pillar Gradient)
El gradiente principal representa el flujo de la tecnología.
- **Violet:** `#A40EBB` (Inicio)
- **Purple:** `#6607DE` (FlowDesk)
- **Electric Blue:** `#007AFF` (Transición)
- **Cyan:** `#5AC8FA` (FlowSell / Final)

> **Nota de Diseño Light Mode:** En modo claro, los acentos cian/naranja deben usarse con moderación para no competir con el fondo blanco. Preferir bordes o textos pequeños sobre fondos sólidos grandes.

---

## 🔘 4. INTERACTIVE COMPONENTS (Sync con Manual de Marca)

### **BTN-GRADIENT** (`.btn-hero-cta`)
El llamado a la acción principal del Hero (Atención máxima).
- **Fondo:** Gradiente Violeta a Morado (`#A40EBB` → `#6607DE`).
- **Texto:** `White` (#FFFFFF)
- **Forma:** `Rounded-xl` (12px) - Moderno y amigable.
- **Sombra:** `Shadow-lg` + Sombra suave del mismo gradiente.

### **BTN-PRIMARY** (`.btn-primary`)
Botones de acción estándar.
- **Fondo:** Azul Azure Sólido (`#007AFF`).
- **Texto:** `White` (#FFFFFF).

### **BTN-SECONDARY** (`.btn-secondary`)
Botones de apoyo o navegación (Ej. CTA Final Bloque 8).
- **Fondo:** `White` (#FFFFFF)
- **Texto:** Morado (`#6607DE`) o `text-foreground` (`#1D1D1F`).
- **Borde:** `border-border` (`#E2E8F0`) si no tiene fondo con gradiente.
- **Hover:** `bg-secondary` (`#F2F2F7`).

---

## 🤖 5. AI PROMPT & SYNC RULE
> **"Si vas a crear un botón o elemento interactivo, verifica siempre la sección 4 de este documento."**

---

## 🌍 6. INTERNATIONALIZATION (i18n)

### 6.1 ESTRATEGIA DE CONTENIDO
El diseño debe ser flexible para soportar la expansión de texto del Español vs Inglés (+25-30% de longitud promedio).

- **Layouts Flexibles:** Evitar anchos fijos (`width: 300px`) en contenedores de texto. Usar `min-width` o `max-width` con `flex-wrap`.
- **Botones:** Los botones deben crecer con el contenido. Evitar romper etiquetas de botones en dos líneas.

### 6.2 FORMATOS REGIONALES

| Dato | Español (ES) | Inglés (EN) | Token/Clase |
| :--- | :--- | :--- | :--- |
| **Ingresos** | `$1.200 USD` | `$1,200 USD` | `.text-data` |
| **Usuarios** | `1.5k Activos` | `1.5k Active` | `.text-ui-label` |
| **Fecha** | `03 ENE 2026` | `JAN 03, 2026` | `.text-muted` |

---

## 📝 7. LOG DE ACTUALIZACIONES
- **2026-02-16:** Adaptación completa a **Flowtify AI Identity**.
    - Cambio a "Vibrant Energy" (Light Mode Only).
    - Implementación del 4-Pillar Gradient.
    - Redefinición de botones y tipografía.

---

## 🎬 8. MOTION TOKENS (GSAP)
Estándares de animación para mantener la coherencia cinematográfica.

### 8.1 FLOW REVEAL (Títulos y Héroes)
El efecto estándar para revelar contenido con elegancia líquida.
- **Estilo:** "Liquid Fade Up".
- **Trigger:** `top 85%` del viewport.
- **Duration:** `1.4s`.
- **Ease:** `power4.out`.
- **Stagger:** `0.2s` (Entre líneas).
- **Start State:** `y: 40, opacity: 0`.
- **End State:** `y: 0, opacity: 1`.

### 8.2 COMPONENT FADE (Tarjetas y Elementos)
- **Duration:** `0.8s`.
- **Ease:** `power2.out`.
- **Distance:** `y: 30px`.